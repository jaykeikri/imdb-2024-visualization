# IMDb 2024 Data Scraping and Visualizations

This project extracts and analyzes movie data from IMDb for the year 2024 using Selenium, stores it in a SQL database, and visualizes it using Streamlit.

## Project Structure
- `data/genre_csvs/`: Stores genre-wise CSV files.
- `scripts/`: Contains scraping, cleaning, and merging scripts.
- `database/`: Contains SQL setup and data insertion scripts.
- `streamlit_app/`: Streamlit dashboard files.
- `docs/`: Documentation and references.

## Tools Used
Python, Selenium, Pandas, SQL, Streamlit, Matplotlib, Seaborn

## Getting Started
Run the scripts in `scripts/` to scrape and store data.
Launch the Streamlit app using:
```bash
streamlit run streamlit_app/dashboard.py
```